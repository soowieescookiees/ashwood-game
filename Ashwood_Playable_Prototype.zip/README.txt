ASHWOOD — PLAYABLE PROTOTYPE

1. Open index.html in a browser to play the prototype.
2. To publish it with GitHub Pages:
   - Create a GitHub repository.
   - Upload index.html, style.css, and game.js.
   - Open Settings > Pages.
   - Set deployment to the main branch/root.
   - Save.
3. The next development step is to turn the story prototype into an explorable first-person neighborhood with clickable/interactable locations.

This prototype intentionally keeps the horror non-graphic and focuses on mystery, suspense, clues, and atmosphere.
